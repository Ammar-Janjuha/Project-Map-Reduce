# Cell 1: Mount Google Drive and navigate to project
from google.colab import drive
import os

# Mount Google Drive
drive.mount('/content/drive')

# Navigate to specific folder
folder_id = '1Cj3vGzXu0eDZjdHl4NuhM-TBfDNbBvDd'
project_path = f'/content/drive/MyDrive/Project Map Reduce'

# Try to find the folder
print("Looking for your project folder...")

# Check if the direct path exists
if os.path.exists(project_path):
    print(f"✓ Found project at: {project_path}")
    os.chdir(project_path)
else:
    # Search for it
    print("Searching for project folder...")
    !find /content/drive/MyDrive -type d -name "*Map*Reduce*" 2>/dev/null

    # Let user select
    search_results = !find /content/drive/MyDrive -type d -name "*Map*Reduce*" 2>/dev/null
    if search_results:
        print(f"\nFound {len(search_results)} possible locations:")
        for i, path in enumerate(search_results[:5]):  # Show first 5
            print(f"{i+1}. {path}")

        # Use the first result
        project_path = search_results[0]
        print(f"\nUsing: {project_path}")
        os.chdir(project_path)
    else:
        # List root to see what's available
        print("\nContents of MyDrive:")
        !ls -la "/content/drive/MyDrive/"
        print("\nPlease check the folder name and update the path.")

# Cell 2: See what files we have
print("=== YOUR PROJECT STRUCTURE ===")
print(f"Current directory: {os.getcwd()}\n")

# List all files
!ls -la

print("\n=== DETAILED FILE LIST ===")
!find . -type f -name "*.c" -o -name "*.sh" -o -name "*.txt" -o -name "*.md" | sort

# Cell 3: Install MPI and compiler
print("Installing MPI and dependencies...")
!apt-get update -qq
!apt-get install -y -qq mpich libopenmpi-dev gcc
print("✓ Installation complete!")

# Verify
print("\n=== VERIFICATION ===")
!which mpicc
!which mpirun
!gcc --version

# Cell 4: Setup for Colab
import os

# Set environment variables for Colab MPI
os.environ['OMPI_ALLOW_RUN_AS_ROOT'] = '1'
os.environ['OMPI_ALLOW_RUN_AS_ROOT_CONFIRM'] = '1'

print("Setting up Colab environment...")

# Make scripts executable
!chmod +x *.sh 2>/dev/null || echo "No shell scripts found"

# List available scripts
print("\nAvailable scripts:")
!ls -la *.sh 2>/dev/null || echo "None"

# Check if we have the C files
print("\nChecking for C source files...")
if os.path.exists('serial_wordcount.c'):
    print("✓ Found serial_wordcount.c")
else:
    # Search for it
    c_files = !find . -name "*.c" 2>/dev/null
    if c_files:
        print(f"Found C files: {c_files}")

# Cell 5: Compile C programs
print("=== COMPILATION ===")

# Try to compile serial version
if os.path.exists('Serial_Version.c'):
    print("Compiling serial version...")
    !gcc -o Serial_Version Serial_Version.c -lm -Wall
    if os.path.exists('Serial_Version'):
        print("✓ Serial version compiled successfully!")
    else:
        print("✗ Serial compilation failed!")
else:
    print("Serial_Version.c not found. Searching...")
    !find . -name "*serial*.c" 2>/dev/null

# Try to compile parallel version
if os.path.exists('Parallel_Version.c'):
    print("\nCompiling parallel version...")
    !mpicc -o Parallel_Version Parallel_Version.c -lm -Wall
    if os.path.exists('Parallel_Version'):
        print("✓ Parallel version compiled successfully!")
    else:
        print("✗ Parallel compilation failed!")
else:
    print("parallel_wordcount.c not found. Searching...")
    !find . -name "*parallel*.c" 2>/dev/null

print("\nCompiled executables:")
!ls -la serial_wordcount parallel_wordcount 2>/dev/null || echo "None"

# Cell 6: Create sample input files
print("=== CREATING TEST FILES ===")

# Check if input files exist
existing_files = !ls input*.txt 2>/dev/null || echo ""
if existing_files:
    print(f"Found existing input files: {existing_files}")
else:
    print("Creating sample input files...")

    # Create sample files using Python file I/O
    with open('input1.txt', 'w') as f:
        f.write('MapReduce is a programming model for processing large datasets.\n')
        f.write('The model involves Map phase and Reduce phase.\n')
        f.write('Hadoop uses MapReduce for big data processing.\n')
        f.write('Parallel computing improves performance significantly.\n')

    with open('input2.txt', 'w') as f:
        f.write('MPI enables parallel programming on distributed systems.\n')
        f.write('Message passing allows communication between processes.\n')
        f.write('Distributed systems consist of multiple computers.\n')
        f.write('Load balancing distributes workloads across resources.\n')

    with open('input3.txt', 'w') as f:
        f.write('Performance benchmarking measures system efficiency.\n')
        f.write('Scalability evaluates performance with more resources.\n')
        f.write('Speedup compares parallel to serial execution.\n')
        f.write('Efficiency measures resource utilization.\n')

    # The large_input.txt needs a slightly different approach to generate dynamic content
    # We'll use a loop to generate the content and write it.
    with open('large_input.txt', 'w') as f:
        for i in range(1, 51):
            f.write(f"Word{i} processing computing system performance\n")

    print("✓ Sample files created!")

print("\nAvailable input files:")
!ls -la *.txt 2>/dev/null || echo "No text files"

# Cell 7: Run serial word count
print("="*70)
print("SERIAL WORD COUNT EXECUTION")
print("="*70)

import time
import subprocess

if os.path.exists('Serial_Version'):
    # Get available input files
    input_files = [f for f in os.listdir('.') if f.startswith('input') and f.endswith('.txt')]
    if not input_files:
        input_files = ['input1.txt', 'input2.txt']

    print(f"Processing files: {input_files}")

    # Measure execution time
    start = time.time()

    # Run serial version
    cmd = ['./Serial_Version'] + input_files
    result = subprocess.run(cmd, capture_output=True, text=True)

    execution_time = time.time() - start

    # Display output
    print(result.stdout)

    if result.stderr:
        print("STDERR:", result.stderr[:500])

    print(f"\n⏱️  Serial execution time: {execution_time:.4f} seconds")

    # Save execution time
    with open('serial_time.txt', 'w') as f:
        f.write(str(execution_time))

    print("✓ Serial execution complete!")
else:
    print("Error: serial_wordcount executable not found!")

# Cell 8: Run parallel word count
print("\n" + "="*70)
print("PARALLEL WORD COUNT EXECUTION")
print("="*70)

if os.path.exists('Parallel_Version'):
    # Get input files
    input_files = [f for f in os.listdir('.') if f.startswith('input') and f.endswith('.txt')]
    if not input_files:
        input_files = ['input1.txt', 'input2.txt']

    print(f"Processing files: {input_files}")

    # Test different numbers of processes
    process_counts = [2, 4]
    parallel_times = {}

    for np in process_counts:
        print(f"\n{'='*40}")
        print(f"Testing with {np} processes")
        print('='*40)

        # Build command
        cmd = ['mpirun', '-np', str(np), '--allow-run-as-root', './Parallel_Version'] + input_files

        # Run and measure time
        start = time.time()
        result = subprocess.run(cmd, capture_output=True, text=True)
        execution_time = time.time() - start

        parallel_times[np] = execution_time

        # Show output
        lines = result.stdout.split('\n')
        # Show relevant parts
        for line in lines:
            if any(keyword in line.lower() for keyword in ['results', 'unique', 'time:', 'process', 'file']):
                print(line)

        print(f"\n⏱️  Execution time: {execution_time:.4f} seconds")

        # Save time
        with open(f'parallel_time_{np}.txt', 'w') as f:
            f.write(str(execution_time))

        # Save results
        if 'parallel_results.txt' in os.listdir('.'):
            !cp parallel_results.txt parallel_results_{np}.txt

    print("\n✓ Parallel execution complete!")
else:
    print("Error: parallel_wordcount executable not found!")

# Cell 9: Analyze and compare performance
print("\n" + "="*70)
print("PERFORMANCE ANALYSIS")
print("="*70)

# Load serial time
serial_time = None
if os.path.exists('serial_time.txt'):
    with open('serial_time.txt', 'r') as f:
        serial_time = float(f.read().strip())
        print(f"Serial execution time: {serial_time:.4f} seconds")
else:
    print("Serial time file not found. Checking results file...")
    if os.path.exists('serial_results.txt'):
        with open('serial_results.txt', 'r') as f:
            content = f.read()
            import re
            match = re.search(r'[Tt]ime:\s*([\d.]+)', content)
            if match:
                serial_time = float(match.group(1))
                print(f"Serial execution time (from results): {serial_time:.4f} seconds")

# Collect parallel times
parallel_results = {}
for np in [2, 4]:
    time_file = f'parallel_time_{np}.txt'
    if os.path.exists(time_file):
        with open(time_file, 'r') as f:
            parallel_results[np] = float(f.read().strip())
    elif os.path.exists(f'parallel_results_{np}.txt'):
        # Extract from results file
        with open(f'parallel_results_{np}.txt', 'r') as f:
            content = f.read()
            match = re.search(r'[Tt]ime:\s*([\d.]+)', content)
            if match:
                parallel_results[np] = float(match.group(1))

# Display comparison
if serial_time and parallel_results:
    print("\n" + "-"*60)
    print(f"{'Configuration':<20} {'Time (s)':<15} {'Speedup':<15} {'Efficiency':<15}")
    print("-"*60)

    best_speedup = 0
    best_config = None

    for np, p_time in sorted(parallel_results.items()):
        speedup = serial_time / p_time
        efficiency = (speedup / np) * 100

        print(f"{f'{np} processes':<20} {p_time:<15.4f} {speedup:<15.2f} {efficiency:<15.1f}%")

        if speedup > best_speedup:
            best_speedup = speedup
            best_config = np

    print("-"*60)

    # Generate report
    report = """MAPREDUCE WORD COUNT - PERFORMANCE REPORT
Generated on Google Colab

EXECUTION SUMMARY:
"""

    report += f"Serial Execution: {serial_time:.4f} seconds\n\n"
    report += "Parallel Execution:\n"

    for np, p_time in sorted(parallel_results.items()):
        speedup = serial_time / p_time
        efficiency = (speedup / np) * 100
        report += f"  {np} processes: {p_time:.4f}s | Speedup: {speedup:.2f}x | Efficiency: {efficiency:.1f}%\n"

    report += f"\nCONCLUSION:\n"
    report += f"• Best configuration: {best_config} processes\n"
    report += f"• Best speedup: {best_speedup:.2f}x faster than serial\n"

    if best_speedup > 1:
        report += "• Parallel implementation shows good speedup!\n"
    else:
        report += "• Parallel implementation needs optimization.\n"

    # Save report
    with open('performance_report_colab.txt', 'w') as f:
        f.write(report)

    print("\n" + report)
    print("\n✓ Report saved to 'performance_report_colab.txt'")

    # Create visualization
    print("\n📊 VISUAL COMPARISON")

    # Simple ASCII bar chart
    if parallel_results:
        max_time = max(parallel_results.values())

        for np, p_time in sorted(parallel_results.items()):
            bar_length = int((p_time / max_time) * 50)
            bar = '█' * bar_length
            speedup = serial_time / p_time
            print(f"{np} procs: {' '*(3-len(str(np)))}{p_time:.4f}s {bar} ({speedup:.2f}x)")

        print(f"Serial: {' '*6}{serial_time:.4f}s {'█'*50}")
else:
    print("Insufficient data for performance analysis!")

# Cell 10: Show generated files and results
print("\n" + "="*70)
print("GENERATED FILES AND RESULTS")
print("="*70)

print("\n📁 All generated files:")
!ls -la *.txt 2>/dev/null || echo "No text files"

print("\n" + "="*40)
print("SERIAL RESULTS SUMMARY")
print("="*40)
if os.path.exists('serial_results.txt'):
    !head -15 serial_results.txt
else:
    print("No serial results file found.")

print("\n" + "="*40)
print("PARALLEL RESULTS SUMMARY")
print("="*40)
for np in [2, 4]:
    result_file = f'parallel_results_{np}.txt'
    if os.path.exists(result_file):
        print(f"\n--- {np} Processes ---")
        !head -10 "{result_file}"
    elif np == 2 and os.path.exists('parallel_results.txt'):
        print(f"\n--- Parallel Results ---")
        !head -10 parallel_results.txt

# Cell 11: Download results to your computer
from google.colab import files

print("="*70)
print("DOWNLOAD RESULTS")
print("="*70)

print("\nAvailable files for download:")
!ls -la *.txt 2>/dev/null

choice = input("\nDo you want to download the results? (y/n): ")

if choice.lower() == 'y':
    files_to_download = []

    # Add performance report
    if os.path.exists('performance_report_colab.txt'):
        files_to_download.append('performance_report_colab.txt')

    # Add serial results
    if os.path.exists('serial_results.txt'):
        files_to_download.append('serial_results.txt')

    # Add parallel results
    for np in [2, 4]:
        if os.path.exists(f'parallel_results_{np}.txt'):
            files_to_download.append(f'parallel_results_{np}.txt')
        elif np == 2 and os.path.exists('parallel_results.txt'):
            files_to_download.append('parallel_results.txt')

    # Download each file
    for file in files_to_download:
        print(f"Downloading: {file}")
        files.download(file)

    print("\n✓ All files downloaded!")
else:
    print("Download skipped.")