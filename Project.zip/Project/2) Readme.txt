=====================================================================================
MapReduce Word Count using MPI							     
Parallel & Distributed Computing Project					     
=====================================================================================

PROJECT OBJECTIVES:
1. Implement MapReduce model using MPI
2. Process multiple text files in parallel
3. Count frequency of each unique word
4. Combine partial results into final word-frequency table
5. Analyze performance and parallel speedup

FILES IN THIS PROJECT:
1. Serial_Version.c  		       	 - Serial implementation
2. Parallel_Version.c 			 - Parallel MPI implementation
3. input1.txt, input2.txt, input3.txt 	 - Sample text files
4. compile_and_run.sh                    - Compilation and execution script
5. README.txt                            - This file


INSTALLATION & COMPILATION:
1. Make the script executable:
   chmod +x compile_and_run.sh
   
2. Run the compilation script:
   ./compile_and_run.sh

   This will:
   - Install MPI if not present
   - Compile both serial and parallel versions
   - Create sample input files
   - Run both versions with sample data

MANUAL COMPILATION:
- Serial version: gcc -o Serial_Version Serial_Version.c -lm
- Parallel version: mpicc -o Parallel_Version Parallel_Version.c .c -lm


RUNNING THE PROGRAMS:
1. Serial Version:
   .Serial_Version file1.txt file2.txt ...
   Example: ./Serial_Version input1.txt input2.txt

2. Parallel Version:
   mpirun -np <number_of_processes> ./parallel_wordcount file1.txt file2.txt ...
   Examples:
   mpirun -np 2 ./Parallel_Version input1.txt input2.txt input3.txt
   mpirun -np 4 ./Parallel_Version input1.txt input2.txt input3.txt

OUTPUT FILES:
1. serial_results.txt - Results from serial execution
2. parallel_results.txt - Results from parallel execution
3. performance.txt - Speedup and efficiency analysis

MAPREDUCE IMPLEMENTATION DETAILS:
- MAP PHASE: Each process reads and processes assigned files independently
- SHUFFLE PHASE: Intermediate results are exchanged between processes
- REDUCE PHASE: Results are merged using tree-based reduction
- Master-Worker: Process 0 acts as master (collects final results)

PERFORMANCE METRICS:
- Speedup = Serial Time / Parallel Time
- Efficiency = (Speedup / Number of Processes) * 100%

NOTES:
- Words are converted to lowercase
- Punctuation is removed from words
- Results are sorted by frequency (highest first)
- The code handles up to 10 files and 5000 unique words per process
