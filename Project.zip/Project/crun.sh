#!/bin/bash

echo "=== MapReduce Word Count Project ==="
echo ""

# Install MPI if not installed
echo "Checking for MPI installation..."
if ! command -v mpicc &> /dev/null; then
    echo "MPI not found. Installing..."
    sudo apt-get update
    sudo apt-get install -y mpich
fi

# Compile serial version
echo "Compiling serial version..."
gcc -o serial_wordcount Serial_Version.c -lm
if [ $? -eq 0 ]; then
    echo "Serial version compiled successfully!"
else
    echo "Failed to compile serial version!"
    exit 1
fi

# Compile parallel version
echo "Compiling parallel version..."
mpicc -o parallel_wordcount Parallel_Version.c -lm
if [ $? -eq 0 ]; then
    echo "Parallel version compiled successfully!"
else
    echo "Failed to compile parallel version!"
    exit 1
fi

# Create sample input files if they don't exist
if [ ! -f input1.txt ]; then
    echo "Creating sample input files..."
    cat > input1.txt << EOF
The quick brown fox jumps over the lazy dog.
The dog barked at the fox, but the fox kept running.
Running through the forest, the fox was quick and brown.
EOF
    
    cat > input2.txt << EOF
Parallel computing is faster than serial computing.
MPI helps in parallel computing across multiple nodes.
Distributed systems and parallel computing work together.
The quick brown fox appears here too.
EOF
    
    cat > input3.txt << EOF
MapReduce is a programming model for processing large data sets.
The model involves Map phase and Reduce phase.
Hadoop uses MapReduce for big data processing.
MapReduce helps in parallel processing of data.
EOF
    echo "Sample input files created!"
fi

echo ""
echo "=== RUNNING SERIAL VERSION ==="
./serial_wordcount input1.txt input2.txt input3.txt

echo ""
echo "=== RUNNING PARALLEL VERSION ==="
echo "Running with 2 processes..."
mpirun -np 2 parallel_wordcount input1.txt input2.txt input3.txt

echo ""
echo "Running with 4 processes..."
mpirun -np 4 parallel_wordcount input1.txt input2.txt input3.txt

echo ""
echo "=== RESULTS SUMMARY ==="
echo "Check the generated files:"
echo "1. serial_results.txt - Results from serial version"
echo "2. parallel_results.txt - Results from parallel version"
echo "3. performance.txt - Performance comparison (if available)"

echo ""
echo "To run with custom files:"
echo "Serial: ./serial_wordcount file1.txt file2.txt ..."
echo "Parallel: mpirun -np <N> ./parallel_wordcount file1.txt file2.txt ..."
